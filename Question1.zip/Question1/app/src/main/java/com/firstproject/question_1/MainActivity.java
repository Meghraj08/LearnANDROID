package com.firstproject.question_1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Students[] students = new Students[5];
        for (int i = 0; i < students.length; i++) {
            students[i] = new Students("Meghraj Mahida - " + (i + 1), "Android Development - " + (i + 1), "50,000 - " + (i + 1));
        }
        RecyclerView recyclerView = findViewById(R.id.studentsList);
        StudentsListAdapter adapter = new StudentsListAdapter(students);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }
}

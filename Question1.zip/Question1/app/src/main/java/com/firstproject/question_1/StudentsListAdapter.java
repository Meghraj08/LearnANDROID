package com.firstproject.question_1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class StudentsListAdapter extends RecyclerView.Adapter<StudentsListAdapter.ViewHolder> {
    private Students[] students;

    StudentsListAdapter(Students[] students) {
        this.students = students;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.students_card, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.nameView.setText(students[position].getName());
        holder.courseView.setText(students[position].getCourse());
        holder.feesView.setText(students[position].getFees());
    }

    @Override
    public int getItemCount() {
        return students.length;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameView, courseView, feesView;

        public ViewHolder(View itemView) {
            super(itemView);
            this.nameView = itemView.findViewById(R.id.name);
            this.courseView = itemView.findViewById(R.id.course);
            this.feesView = itemView.findViewById(R.id.fees);
        }
    }
}

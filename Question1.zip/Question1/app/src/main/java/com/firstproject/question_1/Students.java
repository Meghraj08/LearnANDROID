package com.firstproject.question_1;

public class Students {
    private String name, course, fees;

    public Students() {
    }

    public Students(String name, String course, String fees) {
        this.name = name;
        this.course = course;
        this.fees = fees;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getFees() {
        return fees;
    }

    public void setFees(String fees) {
        this.fees = fees;
    }
}

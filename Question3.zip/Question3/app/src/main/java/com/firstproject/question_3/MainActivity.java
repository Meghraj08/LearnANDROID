package com.firstproject.question_3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.google.android.material.chip.Chip;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CardView studentcard;
        EditText name, age, course, fees;
        Chip gender;
        RadioButton male, female;
        Button submit;
        TextView nameText, ageText, courseText, feesText;

        name = findViewById(R.id.nameT);
        age = findViewById(R.id.ageT);
        course = findViewById(R.id.courseT);
        fees = findViewById(R.id.feesT);

        nameText = findViewById(R.id.nameL);
        ageText = findViewById(R.id.ageL);
        courseText = findViewById(R.id.courseL);
        feesText = findViewById(R.id.feesL);

        male = findViewById(R.id.male);
        female = findViewById(R.id.female);
        gender = findViewById(R.id.gender);

        submit = findViewById(R.id.submit);
        studentcard = findViewById(R.id.studentcard);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                studentcard.setVisibility(View.VISIBLE);
                nameText.setText(name.getText().toString());
                ageText.setText(age.getText().toString());
                courseText.setText(course.getText().toString());
                feesText.setText(fees.getText().toString());

                if (male.isChecked()) {
                    gender.setText(male.getText().toString());
                } else {
                    gender.setText(female.getText().toString());
                }
            }
        });
    }
}

package com.firstproject.mycalc;

public class Calc {
    static int calc(int a, int b, String op) {
        int ans = 0;
        switch (op) {
            case "+":
                ans = a + b;
                break;
            case "-":
                ans = a - b;
                break;
            case "*":
                ans = a * b;
                break;
            case "/":
                ans = a / b;
                break;
        }
        return ans;
    }
}

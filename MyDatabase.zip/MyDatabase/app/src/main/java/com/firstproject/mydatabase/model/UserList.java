package com.firstproject.mydatabase.model;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firstproject.mydatabase.EditUserActivity;
import com.firstproject.mydatabase.R;

import java.util.ArrayList;

public class UserList extends RecyclerView.Adapter<UserList.ViewHolder> {
    private ArrayList<User> users;
    private Context context;

    public UserList(Context context, ArrayList<User> users) {
        this.users = users;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.recycle_view, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        User cuser = users.get(position);
        holder.fullnameView.setText(users.get(position).getFullname());
        holder.usernameView.setText(users.get(position).getUsername());
        holder.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, EditUserActivity.class);
                intent.putExtra("cuser", cuser);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return users.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView fullnameView, usernameView;
        Button button;

        public ViewHolder(View itemView) {
            super(itemView);
            this.fullnameView = itemView.findViewById(R.id.showfullname);
            this.usernameView = itemView.findViewById(R.id.showusername);
            this.button = itemView.findViewById(R.id.editprofile);
        }
    }
}

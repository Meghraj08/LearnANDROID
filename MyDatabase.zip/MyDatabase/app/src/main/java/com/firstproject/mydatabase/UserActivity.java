package com.firstproject.mydatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.firstproject.mydatabase.model.User;


public class UserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        Intent intent = getIntent();
        User user = (User) intent.getSerializableExtra("cuser");
        boolean islogin = intent.getBooleanExtra("islogin",false);

        TextView full,username;
        full = findViewById(R.id.yourfullname);
        username = findViewById(R.id.yourusername);

        full.setText(user.getFullname());
        username.setText(user.getUsername());

        Button edituserprofile = findViewById(R.id.edituserprofile);
        edituserprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserActivity.this,EditUserActivity.class);
                intent.putExtra("cuser",user);
                intent.putExtra("islogin",islogin);
                startActivity(intent);
            }
        });

        Button logout = findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserActivity.this, LoginActivity.class);
                intent.putExtra("cuser",new User());
                intent.putExtra("islogin",false);
                startActivity(intent);
            }
        });
    }
}

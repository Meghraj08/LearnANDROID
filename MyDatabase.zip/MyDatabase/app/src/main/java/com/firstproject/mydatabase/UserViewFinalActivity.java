package com.firstproject.mydatabase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.firstproject.mydatabase.model.UserList;

public class UserViewFinalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_view_final);

        RecyclerView recyclerView = findViewById(R.id.userList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        DBHelper dbHelper = new DBHelper(getApplicationContext(), null, null, 1);
        UserList userList = new UserList(getApplicationContext(), dbHelper.getAllUsers());
        recyclerView.setAdapter(userList);
    }
}

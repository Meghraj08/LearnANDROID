package com.firstproject.mydatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firstproject.mydatabase.model.User;

public class MainActivity extends AppCompatActivity {

    EditText fullname, username, password;
    Button register, login, view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fullname = findViewById(R.id.enterfullname);
        username = findViewById(R.id.enterusername);
        password = findViewById(R.id.enterpassword);
        register = findViewById(R.id.register);
        view = findViewById(R.id.viewUsers);
        login = findViewById(R.id.login);

        Intent intent = getIntent();
        boolean islogin = intent.getBooleanExtra("islogin", false);
        if (islogin) {
            view.setVisibility(View.VISIBLE);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent1 = new Intent(getApplicationContext(), UserViewFinalActivity.class);
                    startActivity(intent1);
                }
            });
        } else {
            view.setVisibility(View.GONE);
        }

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                User user = new User();
                user.setFullname(fullname.getText().toString());
                user.setUsername(username.getText().toString());
                user.setPassword(password.getText().toString());
                Intent intent = new Intent(MainActivity.this, UserViewFinalActivity.class);
                DBHelper dbHelper = new DBHelper(getBaseContext(), "user.db", null, 1);
                try {
                    boolean ans = dbHelper.insertContact(user);
                    if (ans)
                        Toast.makeText(getApplicationContext(), "Data Inserted", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(getApplicationContext(), "Data Insertion Error", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                startActivity(intent);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}

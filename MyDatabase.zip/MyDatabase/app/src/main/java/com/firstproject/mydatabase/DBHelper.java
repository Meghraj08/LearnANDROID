package com.firstproject.mydatabase;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.firstproject.mydatabase.model.User;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    static String DB = "user.db";

    public DBHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DB, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `user` ( `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                "`fullname` TEXT NOT NULL, `username` TEXT NOT NULL UNIQUE," +
                "`password` TEXT NOT NULL);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS `user`");
        onCreate(db);
    }

    public boolean insertContact(@NonNull User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("fullname", user.getFullname());
        contentValues.put("username", user.getUsername());
        contentValues.put("password", user.getPassword());
        long id = db.insert("user", null, contentValues);
        return id > 0;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from user where id=" + id + "", null);
        return res;
    }

    @SuppressLint("Range")
    public User getData(String username, String pass) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from user where `username`='" + username + "' AND `password` = '" + pass + "'", null);
        res.moveToFirst();

        if (!res.isAfterLast()) {
            return new User(
                    res.getInt(res.getColumnIndex("id")),
                    res.getString(res.getColumnIndex("fullname")),
                    res.getString(res.getColumnIndex("username")),
                    res.getString(res.getColumnIndex("password")));
        }
        return null;
    }


    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, "user");
        return numRows;
    }

    public boolean updateContact(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("fullname", user.getFullname());
        contentValues.put("username", user.getUsername());
        contentValues.put("password", user.getPassword());
        db.update("user", contentValues, "id = ? ", new String[]{Integer.toString(user.getId())});
        return true;
    }

    public Integer deleteContact(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("user",
                "id = ? ",
                new String[]{Integer.toString(id)});
    }

    @SuppressLint("Range")
    public ArrayList<User> getAllUsers() {
        ArrayList<User> array_list = new ArrayList<User>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from user", null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            array_list.add(new User(
                    res.getInt(res.getColumnIndex("id")),
                    res.getString(res.getColumnIndex("fullname")),
                    res.getString(res.getColumnIndex("username")),
                    res.getString(res.getColumnIndex("password"))));
            res.moveToNext();
        }
        return array_list;
    }
}

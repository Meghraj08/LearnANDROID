package com.firstproject.mydatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firstproject.mydatabase.model.User;

public class EditUserActivity extends AppCompatActivity {
    User user;
    EditText fullname, username, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user);
        Intent intent = getIntent();
        user = (User) intent.getSerializableExtra("cuser");

        fullname = findViewById(R.id.editfullname);
        username = findViewById(R.id.editusername);
        password = findViewById(R.id.editpassword);

        fullname.setText(user.getFullname());
        username.setText(user.getUsername());
        password.setText(user.getPassword());

        Intent intent1 = getIntent();
        boolean islogin = intent1.getBooleanExtra("islogin", false);

        Button save = findViewById(R.id.save);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user.setFullname(fullname.getText().toString());
                user.setUsername(username.getText().toString());
                user.setPassword(password.getText().toString());
                DBHelper dbHelper = new DBHelper(getApplicationContext(), null, null, 1);
                dbHelper.updateContact(user);
                Toast.makeText(getApplicationContext(), "Updated Successfully", Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(getApplicationContext(), UserViewFinalActivity.class);
                startActivity(intent1);
            }
        });
        if (!islogin) {
            intent = new Intent(EditUserActivity.this, LoginActivity.class);
            startActivity(intent);
        }
    }
}

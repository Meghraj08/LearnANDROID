package com.firstproject.mydatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firstproject.mydatabase.model.User;

public class LoginActivity extends AppCompatActivity {
    EditText username, pass;
    Button login, register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        login = findViewById(R.id.login2);
        register = findViewById(R.id.register2);

        username = findViewById(R.id.loginusername);
        pass = findViewById(R.id.loginpassword);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBHelper dbHelper = new DBHelper(getApplicationContext(), null, null, 1);
                User user = (User) dbHelper.getData(username.getText().toString(), pass.getText().toString());
                if (user != null) {
                    Intent intent = new Intent(LoginActivity.this, UserActivity.class);
                    intent.putExtra("cuser", user);
                    intent.putExtra("islogin", true);
                    startActivity(intent);
                } else {
                    Toast.makeText(getApplicationContext(), "Invalid Credential", Toast.LENGTH_SHORT).show();
                }
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                intent.putExtra("islogin", true);
                startActivity(intent);
            }
        });
    }
}

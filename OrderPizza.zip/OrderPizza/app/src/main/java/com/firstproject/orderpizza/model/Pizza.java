package com.firstproject.orderpizza.model;

import java.io.Serializable;

public class Pizza implements Serializable {
    private int id;
    private String name, size, qty, price;

    public Pizza() {
        this.name = name;
        this.size = size;
        this.qty = qty;
        this.price = price;
    }

    public Pizza(int id, String name, String size, String qty, String price) {
        this.id = id;
        this.name = name;
        this.size = size;
        this.qty = qty;
        this.price = price;
    }

    public Pizza(int id, String fullname, String username, String password) {
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}

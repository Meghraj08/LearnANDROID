package com.firstproject.orderpizza;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.firstproject.orderpizza.model.DBHelper;
import com.firstproject.orderpizza.model.Pizza;

public class EditPizza extends AppCompatActivity {
    Pizza pizza;
    EditText name, size, qty, price;
    Button save;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_pizza);
        Intent intent = getIntent();
        pizza = (Pizza) intent.getSerializableExtra("op");

        name = findViewById(R.id.editpizzaname);
        size = findViewById(R.id.editpizzasize);
        qty = findViewById(R.id.editpizzaqty);
        price = findViewById(R.id.editpizzaprice);
        save = findViewById(R.id.save);

        name.setText(pizza.getName());
        size.setText(pizza.getSize());
        qty.setText(pizza.getQty());
        price.setText(pizza.getPrice());

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EditPizza.this, YourOrder.class);
                pizza.setName(name.getText().toString());
                pizza.setSize(size.getText().toString());
                pizza.setQty(qty.getText().toString());
                pizza.setPrice(price.getText().toString());
                DBHelper dbHelper = new DBHelper(getApplicationContext(), null, null, 1);
                dbHelper.updateContact(pizza);
                Toast.makeText(getApplicationContext(), "Your Order Is Saved", Toast.LENGTH_SHORT).show();
                intent.putExtra("op", pizza);
                startActivity(intent);
            }
        });
    }
}

package com.firstproject.orderpizza;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.firstproject.orderpizza.model.DBHelper;
import com.firstproject.orderpizza.model.Pizza;

public class MainActivity extends AppCompatActivity {

    EditText name, size, qty, price;
    Button order;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.editpizzaname);
        size = findViewById(R.id.editpizzasize);
        qty = findViewById(R.id.editpizzaqty);
        price = findViewById(R.id.editpizzaprice);
        order = findViewById(R.id.save);

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, YourOrder.class);
                Pizza pizza = new Pizza();
                pizza.setName(name.getText().toString());
                pizza.setSize(size.getText().toString());
                pizza.setQty(qty.getText().toString());
                pizza.setPrice(price.getText().toString());
                DBHelper dbHelper = new DBHelper(getApplicationContext(), null, null, 1);
                dbHelper.insertContact(pizza);
                intent.putExtra("op", pizza);
                startActivity(intent);
            }
        });
    }
}

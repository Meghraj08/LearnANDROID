package com.firstproject.orderpizza;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.firstproject.orderpizza.model.Pizza;

public class YourOrder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_order);

        Intent intent = getIntent();
        Pizza pizza = (Pizza) intent.getSerializableExtra("op");

        TextView pname, psize, pqty, pprice;
        Button edit, save2;

        pname = findViewById(R.id.yourpizzaname);
        psize = findViewById(R.id.yourpizzasize);
        pqty = findViewById(R.id.yourpizzaqty);
        pprice = findViewById(R.id.yourpizzaprice);
        edit = findViewById(R.id.editorder);
        save2 = findViewById(R.id.save2);

        pname.setText(pizza.getName());
        psize.setText(pizza.getSize());
        pqty.setText(pizza.getQty());
        pprice.setText(pizza.getPrice());

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(YourOrder.this, EditPizza.class);
                intent.putExtra("op", pizza);
                startActivity(intent);
            }
        });
        
        save2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent();
                Toast.makeText(getApplicationContext(), "Your Order Is Saved", Toast.LENGTH_SHORT).show();
                intent.putExtra("op", pizza);
                startActivity(intent);
            }
        });
    }
}

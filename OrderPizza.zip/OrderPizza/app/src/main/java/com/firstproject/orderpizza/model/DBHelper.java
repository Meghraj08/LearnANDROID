package com.firstproject.orderpizza.model;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {
    static String DB = "pizza.db";

    public DBHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `pizza` ( `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
                "`name` TEXT NOT NULL," +
                "`size`	TEXT NOT NULL," +
                "`qty`	INTEGER NOT NULL," +
                "`price` REAL NOT NULL);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS `pizza`");
        onCreate(db);
    }

    public boolean insertContact(@NonNull Pizza pizza) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", pizza.getName());
        contentValues.put("size", pizza.getSize());
        contentValues.put("qty", pizza.getQty());
        contentValues.put("price", pizza.getPrice());
        long id = db.insert("pizza", null, contentValues);
        return id > 0;
    }

    public Cursor getData(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from user where id=" + id + "", null);
        return res;
    }

    @SuppressLint("Range")
    public Pizza getData(String name, String size, String qty, String price) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from user where `name`='" + name + "', `size` = '" + size + "', `qty` = '" + qty + "', `price` = '" + price + "'", null);
        res.moveToFirst();

        if (!res.isAfterLast()) {
            return new Pizza(
                    res.getInt(res.getColumnIndex("id")),
                    res.getString(res.getColumnIndex("name")),
                    res.getString(res.getColumnIndex("size")),
                    res.getString(res.getColumnIndex("qty")),
                    res.getString(res.getColumnIndex("price")));
        }
        return null;
    }

    public int numberOfRows() {
        SQLiteDatabase db = this.getReadableDatabase();
        int numRows = (int) DatabaseUtils.queryNumEntries(db, "pizza");
        return numRows;
    }

    public boolean updateContact(Pizza pizza) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("name", pizza.getName());
        contentValues.put("size", pizza.getSize());
        contentValues.put("qty", pizza.getQty());
        contentValues.put("price", pizza.getPrice());
        db.update("pizza", contentValues, "id = ? ", new String[]{Integer.toString(pizza.getId())});
        return true;
    }

    public Integer deleteContact(Integer id) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete("pizza",
                "id = ? ",
                new String[]{Integer.toString(id)});
    }

    @SuppressLint("Range")
    public ArrayList<Pizza> getAllPizza() {
        ArrayList<Pizza> array_list = new ArrayList<Pizza>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res = db.rawQuery("select * from pizza", null);
        res.moveToFirst();

        while (res.isAfterLast() == false) {
            array_list.add(new Pizza(
                    res.getInt(res.getColumnIndex("id")),
                    res.getString(res.getColumnIndex("name")),
                    res.getString(res.getColumnIndex("size")),
                    res.getString(res.getColumnIndex("qty")),
                    res.getString(res.getColumnIndex("price"))));
            res.moveToNext();
        }
        return array_list;
    }
}

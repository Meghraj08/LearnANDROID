package com.firstproject.form;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import com.google.android.material.chip.Chip;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CardView namecard;
        EditText name, acc, phone, add;
        Chip gender;
        RadioButton male, female;
        Button submit;
        TextView nameT, accT, phoneT, addT;

        name = findViewById(R.id.nameText);
        acc = findViewById(R.id.accText);
        phone = findViewById(R.id.phoneText);
        add = findViewById(R.id.addText);

        nameT = findViewById(R.id.nameLabel);
        accT = findViewById(R.id.accLabel);
        phoneT = findViewById(R.id.phoneLabel);
        addT = findViewById(R.id.addLabel);

        male = findViewById(R.id.male);
        female = findViewById(R.id.female);
        gender = findViewById(R.id.gender);

        submit = findViewById(R.id.submit);
        namecard = findViewById(R.id.namecard);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                namecard.setVisibility(View.VISIBLE);
                nameT.setText(name.getText().toString());
                accT.setText(acc.getText().toString());
                phoneT.setText(phone.getText().toString());
                addT.setText(add.getText().toString());

                if (male.isChecked()) {
                    gender.setText(male.getText().toString());
                } else {
                    gender.setText(female.getText().toString());
                }
            }
        });
    }
}

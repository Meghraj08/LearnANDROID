package com.firstproject.burgerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText name, qty;
    TextView textView;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Burger burger = new Burger("", "");
        name = findViewById(R.id.burgerName);
        qty = findViewById(R.id.burgerQty);
        textView = findViewById(R.id.burgerNo);
        textView.setText(String.valueOf(burger.burgerNo));
        button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                burger.setBurgerName(name.getText().toString());
                burger.setBurgerQty(qty.getText().toString());
                Intent intent = new Intent(MainActivity.this, ExtraDetails.class);
                intent.putExtra("brg", burger);
                startActivity(intent);
            }
        });
    }
}

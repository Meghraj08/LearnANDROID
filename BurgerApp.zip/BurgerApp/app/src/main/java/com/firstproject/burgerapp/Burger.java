package com.firstproject.burgerapp;

public class Burger {

}

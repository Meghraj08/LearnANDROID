package com.firstproject.burgerapp;

public class ExtraDetails {
}

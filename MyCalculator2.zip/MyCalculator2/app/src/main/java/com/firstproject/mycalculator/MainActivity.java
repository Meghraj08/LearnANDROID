package com.firstproject.mycalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    static private TextView formula, answer;
    static private TextView[] numbers, symbols;
    static private String formulaData = "", operand = "", num1 = "", num2 = "", prev = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        formula = findViewById(R.id.formula);
        answer = findViewById(R.id.answer);

        View viewroot = this.getWindow().getDecorView().findViewById(android.R.id.content);
        numbers = new TextView[10];
        symbols = new TextView[6];

        for (int i = 0; i < symbols.length; i++) {
            symbols[i] = viewroot.findViewWithTag("s" + i);
            symbols[i].setEnabled(false);
        }

        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = viewroot.findViewWithTag("b" + i);
            TextView current = numbers[i];
            current.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (operand != "") {
                        num2 += current.getText().toString();
                        answer.setText(num2);
                    } else {
                        num1 += current.getText().toString();
                        answer.setText(num1);
                        setButtons(symbols, true);
                    }
                }
            });
        }
    }

    private static void setButtons(TextView[] symbols, Boolean enable) {
        for (int i = 0; i < symbols.length; i++) {
            symbols[i].setEnabled(enable);
            if (enable) {
                TextView symbol = symbols[i];
                symbol.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        operations(symbol);
                    }
                });
            }
        }
    }

    private static void operations(TextView textView) {
        operand = textView.getText().toString();
        switch (operand) {
            case "+":
                answer.setText("");
                prev = "+";
                formula.setText(String.valueOf(num1 + operand));
                break;
            case "-":
                answer.setText("");
                prev = "-";
                formula.setText(String.valueOf(num1 + operand));
                break;
            case "*":
                answer.setText("");
                prev = "*";
                formula.setText(String.valueOf(num1 + operand));
                break;
            case "/":
                answer.setText("");
                prev = "/";
                formula.setText(String.valueOf(num1 + operand));
                break;
            case "C":
                num1="";
                num2="";
                prev="";
                operand="";
                answer.setText("");
                formula.setText("");
                break;
            case "=":
                if (!prev.equals("")){
                    int ans=0;
                    try {
                        ans = Calculator.calc(Integer.parseInt(num1), Integer.parseInt(num2), prev);
                        formula.setText(String.valueOf(num1 + prev + num2 + " " + operand));
                        answer.setText(String.valueOf(ans));
                        num1 = String.valueOf(ans);
                        num2 = "";
                        prev = "";
                        operand = "";
                    }catch (Exception e){
                        answer.setText(e.getMessage());
                    }finally {
                        num2="";
                    }
                }
                break;
        }
    }
}

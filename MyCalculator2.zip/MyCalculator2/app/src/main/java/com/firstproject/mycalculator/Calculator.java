package com.firstproject.mycalculator;

public class Calculator {
    static int calc(int a, int b, String op) {
        int ans = 0;
        switch (op) {
            case "+":
                ans = a + b;
                break;
            case "-":
                ans = a - b;
                break;
            case "*":
                ans = a * b;
                break;
            case "/":
                ans = a / b;
                break;
        }
        return ans;
    }
}

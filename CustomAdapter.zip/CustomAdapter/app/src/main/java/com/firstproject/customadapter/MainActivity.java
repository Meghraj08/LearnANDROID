package com.firstproject.customadapter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Student[] students = new Student[5];
        for (int i = 0; i < students.length; i++) {
            students[i] = new Student("Meghraj" + (i + 1), "Java" + (i + 1));
        }
        RecyclerView recyclerView = findViewById(R.id.studentList);
        StudentListAdapter adapter = new StudentListAdapter(students);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }
}

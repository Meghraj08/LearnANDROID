package com.jayapp.imagecapture;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import java.net.MalformedURLException;
import java.net.URL;

public class Url_Activity<button> extends AppCompatActivity implements View.OnClickListener {

    private static final int REQUEST_INTERNET_PERMISSION = 301;
    String intentData = "";
    Uri uri = this.getIntent().getData();
    URL url = new URL(uri.getScheme(), uri.getHost(), uri.getPath());


    public Url_Activity() throws MalformedURLException {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_url_);

        Intent intent = getIntent();
        Uri uri = intent.getData();
        try {
            if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.INTERNET) ==
                    PackageManager.PERMISSION_GRANTED) {
                url = new URL(uri.getScheme(), uri.getHost(), uri.getPath());
            } else {
                showAlert();
                Log.d("PERMISSION_REJECTED", "PERMISSION NOT GIVEN");
                ActivityCompat
                        .requestPermissions(
                                this,
                                new String[]{Manifest.permission.INTERNET},
                                301);
            }
        } catch (MalformedURLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    private void showAlert() {
        AlertDialog alertDialog = new AlertDialog.Builder(Url_Activity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("App needs to access the Internet.");

        alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, "DONT ALLOW",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        finish();
                    }
                });

        alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "ALLOW",
                new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        ActivityCompat.requestPermissions(Url_Activity.this,
                                new String[]{Manifest.permission.INTERNET},
                                301);
                    }
                });
        alertDialog.show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button2:
                startActivity(new Intent(Url_Activity.this, ScannerActivity.class));
                break;
        }
    }
}
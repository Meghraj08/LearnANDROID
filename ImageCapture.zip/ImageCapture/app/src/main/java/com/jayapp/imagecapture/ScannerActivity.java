package com.jayapp.imagecapture;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.vision.CameraSource;
import com.google.android.gms.vision.Detector;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.android.gms.vision.barcode.BarcodeDetector;

import java.io.IOException;

public class ScannerActivity extends AppCompatActivity {

    private static final int REQUEST_CAMERA_PERMISSION = 101;
    SurfaceView surfaceView;
    Button button;
    TextView textView;
    String intentData = "";
    private BarcodeDetector barcodeDetector;
    private CameraSource cameraSource;

    boolean isNumber;

    {
        isNumber = false;
    }

    boolean isScanned = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner);

        surfaceView = findViewById(R.id.surfaceView);
        button = findViewById(R.id.button2);
        textView = findViewById(R.id.textView);

        button.setOnClickListener(v -> {
            if (intentData.length() > 0) {
                if (isScanned)
                    startActivity(new Intent(ScannerActivity.this, ScannerActivity.class).putExtra("qr_data", intentData));
                else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(intentData)));
            }
        });

        button.setOnClickListener(v -> {
            if (intentData.length() > 0) {
                if (isNumber)
                    startActivity(new Intent(ScannerActivity.this, Call_Activity.class).putExtra("qr_data", intentData));
                else startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(intentData)));
            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        initialiseDetectorsAndSources();
    }

    @Override
    protected void onPause() {
        super.onPause();
        cameraSource.release();
    }

    @Override
    protected void onResume() {
        super.onResume();
        initialiseDetectorsAndSources();
    }

    private void initialiseDetectorsAndSources() {
        barcodeDetector = new BarcodeDetector.Builder(this)
                .setBarcodeFormats(Barcode.ALL_FORMATS)
                .build();

        cameraSource = new CameraSource.Builder(this, barcodeDetector)
                .setRequestedPreviewSize(1920, 1080)
                .setAutoFocusEnabled(true) //you should add this feature
                .build();

        surfaceView.getHolder().addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                try {
                    if (ActivityCompat.checkSelfPermission(ScannerActivity.this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        cameraSource.start(surfaceView.getHolder());
                    } else {
                        ActivityCompat.requestPermissions(ScannerActivity.this, new
                                String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void surfaceChanged(@NonNull SurfaceHolder holder, int format, int width, int height) {

            }

            @Override
            public void surfaceDestroyed(@NonNull SurfaceHolder holder) {
                cameraSource.stop();
            }
        });

        barcodeDetector.setProcessor(new Detector.Processor<Barcode>() {
            @Override
            public void release() {
                Toast.makeText(getApplicationContext(), "To prevent memory leaks barcode scanner has been stopped", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void receiveDetections(Detector.Detections<Barcode> detections) {
                final SparseArray<Barcode> barcodes = detections.getDetectedItems();
                if (barcodes.size() != 0) {
                    textView.post(new Runnable() {
                        @Override
                        public void run() {

                            if (barcodes.valueAt(0).rawValue != null) {
                                textView.removeCallbacks(null);
                                intentData = barcodes.valueAt(0).rawValue;
                                textView.setText(intentData);
                                isScanned = true;
                                button.setText("Send to Other Activity");
                            } else {
                                isScanned = false;
                                button.setText("Send Data");
                                intentData = barcodes.valueAt(0).displayValue;
                                textView.setText(intentData);
                            }
                        }
                    });
                }
            }
        });
    }
}
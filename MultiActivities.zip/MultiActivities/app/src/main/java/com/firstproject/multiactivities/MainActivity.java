package com.firstproject.multiactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText name, roll, phone, add;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.nameText);
        roll = findViewById(R.id.rollText);
        phone = findViewById(R.id.phoneText);
        add = findViewById(R.id.addText);
        submit = findViewById(R.id.submit);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Student student = new Student();
                student.setName(name.getText().toString());
                student.setRoll(roll.getText().toString());
                student.setPhone(phone.getText().toString());
                student.setAdd(add.getText().toString());
                Intent intent = new Intent(MainActivity.this, StudentDetails.class);
                intent.putExtra("std", student);
                startActivity(intent);
            }
        });
    }
}

package com.firstproject.multiactivities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class StudentDetails extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_details);

        Intent intent = getIntent();
        Student student = (Student) intent.getSerializableExtra("std");
        TextView name, roll, phone, add;
        name = findViewById(R.id.nameT);
        roll = findViewById(R.id.rollT);
        phone = findViewById(R.id.phoneT);
        add = findViewById(R.id.addT);
        name.setText(student.getName());
        roll.setText(student.getRoll());
        phone.setText(student.getPhone());
        add.setText(student.getAdd());
    }
}
